# meet-auto-quit-extension
Extensão para google chrome que sai do Google Meet se a reunião reduzir o quorum. O usuário seleciona um quorum minimo que ativa a funcionalidade e qual a porcentagem do máximo que faz ele sair. 

Criado como trabalho final para o curso CS50. 

## CS50 Final project
#### Video Demo: 
#### Description: Google Chrome extension that quits from a meet based on users settings abtou quorum. For example, quits if thr actual quorum is 50% of the maximum 